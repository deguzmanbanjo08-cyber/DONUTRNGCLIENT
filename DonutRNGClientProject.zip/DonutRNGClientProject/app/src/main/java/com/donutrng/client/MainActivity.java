package com.donutrng.client;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Switch;

public class MainActivity extends Activity {
  int bg=Color.rgb(10,13,20), panel=Color.rgb(20,25,36), cyan=Color.rgb(70,224,255);
  LinearLayout root; TextView status;
  public void onCreate(Bundle b) {
    super.onCreate(b); getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
    root=new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(18),dp(20),dp(18),dp(16)); root.setBackgroundColor(bg);
    root.addView(txt("DONUTRNG",26,cyan,true));
    TextView sub=txt("BEDROCK COMPANION  •  BUILD 0.1",11,Color.LTGRAY,false); LinearLayout.LayoutParams sp=lp(-1,-2); sp.topMargin=dp(4); root.addView(sub,sp);
    LinearLayout hero=card(); hero.addView(txt("CLIENT CONTROL",16,Color.WHITE,true));
    TextView note=txt("Mobile-first interface starter. Switches are UI-only until real game integration exists.",13,Color.rgb(190,200,216),false); LinearLayout.LayoutParams np=lp(-1,-2); np.topMargin=dp(8); hero.addView(note,np);
    LinearLayout.LayoutParams hp=lp(-1,-2); hp.topMargin=dp(18); root.addView(hero,hp);
    TextView section=txt("VISUAL MODULES",13,cyan,true); LinearLayout.LayoutParams sec=lp(-1,-2); sec.topMargin=dp(22); sec.bottomMargin=dp(8); root.addView(section,sec);
    addToggle("Hologram visuals","UI preview only — no in-game X-ray renderer.",false);
    addToggle("Full-grown amethyst","Targets minecraft:cluster only; ignores all bud stages.",true);
    addToggle("Block tracers","Requires supported game/render integration.",false);
    addToggle("Freecam","Not available from a normal companion app.",false);
    addToggle("Sus Chunk Finder","No hidden-chunk scan is connected in this starter.",false);
    status=txt("STATUS: STARTER UI • NO GAME CONNECTION",11,Color.rgb(255,195,90),true); LinearLayout.LayoutParams st=lp(-1,-2); st.topMargin=dp(18); root.addView(status,st);
    TextView footer=txt("No real-money currency. No anti-cheat bypass is included.",11,Color.GRAY,false); LinearLayout.LayoutParams fp=lp(-1,-2); fp.topMargin=dp(10); root.addView(footer,fp);
    ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.addView(root); setContentView(scroll);
  }
  void addToggle(String name,String desc,boolean checked) {
    LinearLayout c=card(), row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
    LinearLayout left=new LinearLayout(this); left.setOrientation(1); left.addView(txt(name,15,Color.WHITE,true));
    TextView d=txt(desc,11,Color.rgb(160,171,190),false); LinearLayout.LayoutParams dp=lp(-1,-2); dp.topMargin=dp(4); left.addView(d,dp);
    row.addView(left,new LinearLayout.LayoutParams(0,-2,1)); Switch sw=new Switch(this); sw.setChecked(checked);
    sw.setOnCheckedChangeListener((button,on)->status.setText("STATUS: UI SWITCH CHANGED • GAME FEATURE NOT CONNECTED"));
    row.addView(sw); c.addView(row); LinearLayout.LayoutParams cp=lp(-1,-2); cp.topMargin=dp(8); root.addView(c,cp);
  }
  LinearLayout card() { LinearLayout c=new LinearLayout(this); c.setOrientation(1); c.setPadding(dp(14),dp(14),dp(14),dp(14)); GradientDrawable d=new GradientDrawable(); d.setColor(panel); d.setCornerRadius(dp(14)); d.setStroke(dp(1),Color.rgb(42,57,77)); c.setBackground(d); return c; }
  TextView txt(String s,int size,int color,boolean bold) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
  LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
  int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
}
