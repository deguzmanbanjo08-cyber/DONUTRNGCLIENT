# DonutRNG Bedrock Companion — starter project

Target: Android app for Minecraft Bedrock / MCPE 26.52 (target version only; compatibility has not been tested against the game).

## Current status
- Android Java project with a dark mobile menu.
- Placeholder toggles and a small amethyst rule note.
- GitHub Actions workflow to compile a debug APK in the cloud.

## Important limits
This is **not a working Minecraft client or proxy**. It does not connect to a LAN world or public server, inject into Minecraft, scan hidden chunks, render X-ray, or implement freecam/tracers. The menu switches are placeholders. The workflow only compiles the Android app; a successful build does not mean Minecraft integration exists.

## Build APK using GitHub Actions
1. Create a GitHub repository.
2. Upload the *contents* of this folder to the repository root (including `.github/workflows/android-apk.yml`). Do not upload only the ZIP file.
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** in the workflow list.
5. Tap **Run workflow** and confirm.
6. When the run finishes successfully, open it and download the `DonutRNG-debug-APK` artifact. Extract the downloaded artifact ZIP to get `app-debug.apk`.

## Requirements for real MCPE support
A Bedrock-compatible network/proxy implementation and tested game integration are still needed. A regular Android menu app cannot automatically join a specific server just because an IP and port are typed in.
